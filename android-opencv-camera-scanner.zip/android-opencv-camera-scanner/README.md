# Android Cam Scanner Using OpenCV

This repository is a simple example of an application like CamScanner using OpenCV

![](https://raw.githubusercontent.com/aashari/android-opencv-camscanner/master/screenshot/Screenshot_20180429-043252_Camera%20Scanner.jpg)

![](https://raw.githubusercontent.com/aashari/android-opencv-camscanner/master/screenshot/Screenshot_20180429-043305_Camera%20Scanner.jpg)

![](https://raw.githubusercontent.com/aashari/android-opencv-camscanner/master/screenshot/Screenshot_20180429-043311_Camera%20Scanner.jpg)

![](https://raw.githubusercontent.com/aashari/android-opencv-camscanner/master/screenshot/Screenshot_20180429-043319_Camera%20Scanner.jpg)
