package id.aashari.code.camerascanner.helpers;

import android.graphics.Bitmap;

public class MyConstants {
    public final static int GALLERY_IMAGE_LOADED = 1001;
    public static Bitmap selectedImageBitmap;
}
