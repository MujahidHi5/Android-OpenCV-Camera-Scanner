package org.opencv.osgi;

/**
 * Dummy interface to allow some integration testing within OSGi implementation.
 */
public interface OpenCVInterface
{
}
